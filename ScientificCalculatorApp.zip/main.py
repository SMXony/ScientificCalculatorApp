
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from math import *

KV = '''
<CalculatorLayout>:
    orientation: 'vertical'
    padding: 10
    spacing: 10

    TextInput:
        id: display
        text: ''
        readonly: True
        font_size: 32
        size_hint_y: 0.2
        background_color: (0, 0, 0, 1)
        foreground_color: (1, 1, 1, 1)

    GridLayout:
        cols: 4
        spacing: 5
        size_hint_y: 0.8

        Button: text: '7'; on_press: root.press('7')
        Button: text: '8'; on_press: root.press('8')
        Button: text: '9'; on_press: root.press('9')
        Button: text: '/'; on_press: root.press('/')

        Button: text: '4'; on_press: root.press('4')
        Button: text: '5'; on_press: root.press('5')
        Button: text: '6'; on_press: root.press('6')
        Button: text: '*'; on_press: root.press('*')

        Button: text: '1'; on_press: root.press('1')
        Button: text: '2'; on_press: root.press('2')
        Button: text: '3'; on_press: root.press('3')
        Button: text: '-'; on_press: root.press('-')

        Button: text: '.'; on_press: root.press('.')
        Button: text: '0'; on_press: root.press('0')
        Button: text: '='; on_press: root.calculate()
        Button: text: '+'; on_press: root.press('+')

        Button: text: 'C'; on_press: root.clear()
        Button: text: 'sqrt'; on_press: root.scientific('sqrt')
        Button: text: 'sin'; on_press: root.scientific('sin')
        Button: text: 'cos'; on_press: root.scientific('cos')

        Button: text: 'tan'; on_press: root.scientific('tan')
        Button: text: 'log'; on_press: root.scientific('log')
        Button: text: 'ln'; on_press: root.scientific('ln')
        Button: text: '^'; on_press: root.press('**')
'''

class CalculatorLayout(BoxLayout):
    def press(self, value):
        self.ids.display.text += value

    def clear(self):
        self.ids.display.text = ""

    def calculate(self):
        try:
            expression = self.ids.display.text
            result = str(eval(expression))
            self.ids.display.text = result
        except:
            self.ids.display.text = "Error"

    def scientific(self, func):
        try:
            expression = self.ids.display.text
            value = float(eval(expression))
            if func == 'sqrt':
                result = sqrt(value)
            elif func == 'sin':
                result = sin(radians(value))
            elif func == 'cos':
                result = cos(radians(value))
            elif func == 'tan':
                result = tan(radians(value))
            elif func == 'log':
                result = log10(value)
            elif func == 'ln':
                result = log(value)
            self.ids.display.text = str(result)
        except:
            self.ids.display.text = "Error"

class CalculatorApp(App):
    def build(self):
        Builder.load_string(KV)
        return CalculatorLayout()

if __name__ == '__main__':
    CalculatorApp().run()
